function hora() {
    var hora = document.getElementById("hora").value;

    var patt1 = /^([0-2]{1}\d{1})\:([0-6]{1}\d{1})(\:[0-6]{1}\d{1})?$/;

    if (patt1.test(hora)) {
        return window.alert("Formato correcto");
    } else {
        return window.alert("Formato incorrecto");
    }
}
