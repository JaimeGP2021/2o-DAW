function gen_random() {
    for (let i = 0; i < 10; i++) {
        document.write((Math.floor(Math.random() * 20 )) + "<br>" );
    }
}
