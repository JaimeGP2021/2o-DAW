function abrir()
{
    window.open("https://www.google.com/", "Google", "popup, width=300, height=300");
}
