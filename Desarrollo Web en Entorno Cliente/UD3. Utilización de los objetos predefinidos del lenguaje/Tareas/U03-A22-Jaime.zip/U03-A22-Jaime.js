var a = document.getElementById("A");

function origen() {
    a.style.fontSize = "initial";
}

function agranda() {
    a.style.fontSize = "larger";

}

function reduce() {
    a.style.fontSize = "smaller";

}
