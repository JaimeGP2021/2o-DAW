// Realizar un script que al terminarse de cargar, muestre un mensaje indicando que la página se ha 
// cargado correctamente y dando la bienvenida.

window.addEventListener("load", () => {
  window.alert('La página ha sido cargada completamente');
});
