// Coloque en la aplicación una imagen, y que se cambie por otra imagen, y ésta se mantenga 
// mientras el usuario está pulsando algún botón del ratón, cuando suelte debe volver la primera 
// imagen. 

var jamon = document.getElementById("cerdo");

document.addEventListener("mousedown", () => {
  jamon.src = "05_cerdo02.jpeg";
});

document.addEventListener("mouseup", () => {
  jamon.src = "05_cerdo01.jpg";
});
