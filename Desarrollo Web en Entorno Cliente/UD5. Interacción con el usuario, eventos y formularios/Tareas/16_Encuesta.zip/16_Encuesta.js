// Realice un script que permita llevar un contador de todas las veces que se ha visitado una
// página.

function getCookie(cname) {
  let name = cname + "=";
  let decodedCookie = decodeURIComponent(document.cookie);
  let ca = decodedCookie.split(";");
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == " ") {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function valcook() {
  var total = 0;
  document.querySelectorAll(".barra").forEach((item) => {
    let galleta = getCookie(item.id);
    if (galleta == "") {
      document.cookie = item.id + "=" + item.value;
    } else {
      item.value = galleta;
      total += parseInt(galleta);
    }
  });
  document.querySelectorAll(".barra").forEach((item) => {
    item.max = total;
  });
}

function votacion() {
  document.querySelectorAll(".opcion").forEach((item) => {
    if (item.checked) {
      document.cookie =
        "pro_" +
        item.id +
        "=" +
        String(parseInt(getCookie("pro_" + item.id)) + 1);
      valcook();
    }
  });
}

var botar = document.getElementById("voto");
botar.addEventListener("click", votacion);
window.addEventListener("load", valcook);
