// Realiza el siguiente formulario  - Cuando pulse Haz clic para enviar información, se enviará la información a un correo 
// electrónico en texto plano. - Cuando pulse en Haz clic sobre mí, se redirigirá a la página de google.  : 9. Modifica el formulario anterior, según la materia seleccionada, debe enviarle el cuestionario a un 
// profesor distinto.  10.  Modifica el formulario anterior, siendo el día preferente el día que haya marcado como 
// disponible. Si marca varios, que coja el último.  11.  Modifica el formulario anterior, según el color de icono seleccionado, cambie el color de fondo 
// del formulario.            

var boton = document.getElementById('google')

boton.onclick = ()=> location.replace('https://www.google.es/') 
