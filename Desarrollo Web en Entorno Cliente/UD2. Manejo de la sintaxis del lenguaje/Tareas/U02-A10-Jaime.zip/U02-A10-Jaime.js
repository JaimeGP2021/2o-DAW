function tabla() {
    var num = parseInt(prompt("Introduce un número"));
    
    for (i=0;i<=10;i++)
        document.write(num+ " x " + i + " = "+(num*i)+"<br>")
}
