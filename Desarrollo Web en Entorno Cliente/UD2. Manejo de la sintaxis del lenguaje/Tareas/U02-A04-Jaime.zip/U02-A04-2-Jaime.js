document.write("<p>Bienvenido al mundo del JavaScript<p>");
