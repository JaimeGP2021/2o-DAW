<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Libros</title>
</head>

<body>
    <table class="table-auto">
        <thead>
            <tr>
                <th>Titulo</th>
                <th>Autor</th>
                <th>Editar</th>
                <th>Mostrar</th>
                <th>Borrar</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $libros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($libro->titulo); ?></td>
                    <td><?php echo e($libro->autor); ?></td>
                    <td>
                        <form action="<?php echo e(route('libros.edit', $libro)); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <button type="submit">Editar</button>
                        </form>
                    </td>
                    <td>
                        <button type="button"><a href=<?php echo e(route('libros.show', $libro)); ?>>Mostrar</a></button>
                    </td>
                    <td>
                        <form action="<?php echo e(route('libros.destroy', $libro)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('Delete'); ?>
                            <button type="submit">Borrar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <button><a href="<?php echo e(route('libros.create')); ?>">Insertar nuevo libro</a></button>

</body>

</html>
<?php /**PATH /home/jaime/examen/biblioteca/resources/views/libros/index.blade.php ENDPATH**/ ?>