<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Show libro</title>
</head>

<body>
    <p>El libro <b><?php echo e($libro->titulo); ?></b> ha sido escrito por <b><?php echo e($libro->autor); ?>.</b></p>
    <table>
        <tr>
            <th>Ejemplar</th>
            <th>Estado</th>
            <th>Fecha_préstamo</th>
        </tr>
        <?php $__currentLoopData = $libro->ejemplares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejemplar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href=<?php echo e(route('ejemplares.show', $ejemplar)); ?>><?php echo e($ejemplar->codigo); ?></a></td>

                <td><?php
                    if ($ejemplar->prestamo) {
                        echo 'Prestado';
                    } else {
                        echo 'Disponible';
                    }
                ?></td>
                <td><?php
                    if ($ejemplar->prestamo) {
                        echo $ejemplar->prestamo->fecha_hora;
                    }
                ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>

</html>
<?php /**PATH /home/jaime/examen/biblioteca/resources/views/libros/show.blade.php ENDPATH**/ ?>