<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreDistribuidoraRequest;
use App\Http\Requests\UpdateDistribuidoraRequest;
use App\Models\Distribuidora;

class DistribuidoraController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreDistribuidoraRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Distribuidora $distribuidora)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Distribuidora $distribuidora)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDistribuidoraRequest $request, Distribuidora $distribuidora)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Distribuidora $distribuidora)
    {
        //
    }
}
